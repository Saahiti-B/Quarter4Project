import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.util.*;
//textprompts https://github.com/tips4java/tips4java/blob/main/source/TextPromptDemo.java
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class ActionMove extends ActionCard{
    //card that is randomly drawn, interspaced with the trivia questions
    private Color color;
    private int x;
    private int y;


    public ActionMove(Color color, int x, int y){
        super(color,x,y);
    }

    public void drawCard(Graphics g){
        g.setColor(super.getCardColor());
        g.fillRect(55,85,50,50);
        g.fillRect(595,85,50,50);
        g.fillRect(595,625,50,50);

        g.setColor(Color.BLACK);
        Font font = new Font("Courier", Font.PLAIN, 5);
        g.drawString("MOVE", 57, 105);
        g.drawString("BACK 2", 55, 117);
        g.drawString("2", 60, 130);
        g.drawString("MOVE", 597, 105);
        g.drawString("BACK", 595, 117);
         g.drawString("2", 600, 130);
        g.drawString("MOVE", 597, 650);
        g.drawString("BACK", 595, 660);
         g.drawString("2", 600, 670);
    }
}