//backend
import java.lang.Math;
public class JavaLand{
    //write methods to keep track of game (players, points, positions, etc.)
    //write dice method (rolling, not drawing)
    public JavaLand(){
        
    }

    public int diceRolled(){
        //use 1 die
        return (int) (Math.random() * 6 + 1);
    }
    
}